function Clique() {
    var saida = document.getElementById('resultado')
    var num = Number(document.getElementById('fnum').value)
    saida.innerHTML += `<h2>Contando de 0 até ${num}</h2>`
}