function Clique() {
    var n1 = Number(window.prompt('Digite um número: '))
    var n2 = Number(window.prompt('Digite outro número: '))
    var result = document.querySelector('section#resultado')

    result.innerHTML = `<p>A soma entre <mark>${n1}</mark> e <mark>${n2}</mark> é igual a <strong>${n1+n2}</strong></p>`
}