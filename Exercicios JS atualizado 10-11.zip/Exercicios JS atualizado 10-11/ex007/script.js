function Clique() {
    var nome = window.prompt('Qual é o nome do aluno?')
    var n1 = Number(window.prompt(`Qual foi a primeira nota de ${nome}?`))
    var n2 = Number(window.prompt(`Além de ${n1}, qual foi a outra nota de ${nome}?`))
    var result = document.querySelector('section#resultado')
    var result2 = document.querySelector('section#resultado2')
    var result3 = document.querySelector('section#resultado3')

    result.innerHTML = `<p>Calculando a média final de <mark>${nome}</mark></p>`
    result2.innerHTML = `<p>As notas obtidas foram <mark>${n1}</mark> e <mark>${n2}</mark></p>`
    result3.innerHTML = `<p>A média final será <mark>${n1/n2}</mark></p>`
}