function Clique() {
    var n1 = Number(window.prompt('Primeiro valor:'))
    var n2 = Number(window.prompt('Segundo valor:'))
    var op = Number(window.prompt(`Valores informados: ${n1} e ${n2}. \nO que vamos fazer? \n[1] Somar \n[2] Subtrair \n[3] Multiplicar \n[4] Dividir`))

    var resultado = document.getElementById('resultado')
    resultado.innerHTML = `<h2>Calculando...</h2>`

    switch (op) {
        case 1:
            resultado.innerHTML += `<p>${n1} + ${n2} = <strong>${n1+n2}</strong></p>`
            break
        case 2:
            resultado.innerHTML += `<p>${n1} - ${n2} = <strong>${n1-n2}</strong></p>`
            break
        case 3:
            resultado.innerHTML += `<p>${n1} x ${n2} = <strong>${n1*n2}</strong></p>`
            break
        case 4:
            resultado.innerHTML += `<p>${n1} / ${n2} = <strong>${n1/n2}</strong></p>`
            break
    }
}