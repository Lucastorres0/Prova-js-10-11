function Clique() {
    var ano = window.prompt('Em que ano você nasceu?')
    var result = document.querySelector('section#resultado')

    result.innerHTML = `<p>Quem nasceu em ${ano} vai completar <strong>${2023 - ano}</strong> anos em 2023.</p>`
}