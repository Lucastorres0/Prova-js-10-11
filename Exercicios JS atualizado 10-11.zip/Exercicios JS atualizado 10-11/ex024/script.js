
function Clique() {
    var contar = document.getElementById('resultado')

    contar.innerHTML += `<h2>Contagem Regressiva de 10 a 1</h2>`
    var cont = 10
    while (cont >= 1) {
        contar.innerHTML += ` ${cont} 👉`
        cont -- // Corresponde a cont = cont - 1
    }
    contar.innerHTML += ` 🏁`
}