function Clique() {
    var agora = new Date
    var saida = document.getElementById('resultado')
    saida.innerHTML = `<p>O que eu recebi do sistema foi <mark>${agora}</mark></p>`
}