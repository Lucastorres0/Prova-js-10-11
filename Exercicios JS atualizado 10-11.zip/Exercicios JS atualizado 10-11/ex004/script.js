function Clique() {
    var nome = window.prompt('Qual é o seu nome?')
    var result = window.document.getElementById('resultado')
    result.innerHTML = `<p>Olá, <strong>${nome}</strong>! É um grande prazer te conhecer!</p>`;
}