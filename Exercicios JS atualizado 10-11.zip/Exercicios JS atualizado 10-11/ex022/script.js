function Clique() {
    var contar = document.getElementById('resultado')

    contar.innerHTML += `<h2>Contando de 1 até 10, marcando os pares</h2>`

    var cont = 1
    while (cont <= 10) {
        if (cont % 2 == 0) {
            contar.innerHTML += `<mark><strong> ${cont} </strong></mark>&#x1F449;`    
        } else {
            contar.innerHTML += ` ${cont} 👉`
        }
        cont ++
    }
    contar.innerHTML += ` 🏁`
}