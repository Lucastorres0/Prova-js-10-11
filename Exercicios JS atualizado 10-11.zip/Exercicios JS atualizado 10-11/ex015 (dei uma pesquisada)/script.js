var meses = new Array('Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez')
var semana = new Array ('Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb')
var agora = new Date
var saida = document.getElementById('resultado')
var dia = agora.getDate()
var mes = agora.getMonth()
var ano = agora.getFullYear()
var sem = agora.getDay()
var hora = agora.getHours()
var min = agora.getMinutes()
var seg = agora.getSeconds()

function Clique() {
    resultado.innerHTML = `<p>Dia: <mark>${dia}</mark></p>`
    resultado.innerHTML += `<p>Mês: <mark>${meses[mes]}</mark></p>`
    resultado.innerHTML += `<p>Ano: <mark>${ano}</mark></p>`
    resultado.innerHTML += `<p>Dia da semana: <mark>${semana[sem]}</mark></p>`
    resultado.innerHTML += `<p>Hora: <mark>${hora}</mark></p>`
    resultado.innerHTML += `<p>Minutos: <mark>${min}</mark></p>`
    resultado.innerHTML += `<p>Segundos: <mark>${seg}</mark></p>`
}