function Clique() {
    var saida = document.getElementById('resultado')
}