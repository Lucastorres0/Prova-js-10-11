function Clique() {
    var contar = document.getElementById('resultado')

    contar.innerHTML += `<h2>Contando de 1 até 10</h2>`

    var cont = 1
    while (cont <= 10) {
        resultado.innerHTML += ` ${cont}  👉 `
        cont ++
    }
    contar.innerHTML += ` 🏁;`
}