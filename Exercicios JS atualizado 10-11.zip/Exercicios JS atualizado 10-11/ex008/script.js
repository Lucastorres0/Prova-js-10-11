function Clique() {
    var n1 = Number(window.prompt('Digite um número: '))
    var result = document.querySelector('section#resultado')

    result.innerHTML = `<p>O número a ser analisado será o <strong>${n1}</strong></p><hr>`
    result.innerHTML += `<p>O seu valor absoluto é ${Math.abs(n1)}</p>`
    result.innerHTML += `<p>A sua parte inteira é ${Math.trunc(n1)}</p>`
    result.innerHTML += `<p>O valor inteiro mais próximo é ${Math.round(n1)}</p>`
    result.innerHTML += `<p>A sua raiz quadrada é ${Math.sqrt(n1)}</p>` 
    result.innerHTML += `<p>A sua raiz cúbica é ${Math.cbrt(n1)}</p>`        
    result.innerHTML += `<p>O valor de ${n1}<sup>2</sup> é ${Math.pow(n1, 2)}</p>`
    result.innerHTML += `<p>O valor de ${n1}<sup>3</sup> é ${Math.pow(n1, 3)}</p>`
}