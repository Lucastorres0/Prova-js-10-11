function Clique() {
    var contar = document.getElementById('resultado')

    contar.innerHTML += `<h2>Números pares de 1 até 10</h2>`
    var cont = 2
    while (cont <= 10) {
        contar.innerHTML += ` ${cont} 👉`
        cont += 2 // Corresponde a cont = cont + 2
    }
    contar.innerHTML += ` 🏁`
}