function Clique() {
    var mês = window.prompt('Digite o mês em extenso (ex: Setembro, Janeiro)')
    var resultado = document.querySelector('section#resultado')

    var estação
    switch (mês.toUpperCase()) {
        case 'JANEIRO': case 'FEVEREIRO': case 'MARÇO': case '1': case '2': case '3':
            estação = 'INVERNO'
            break
        case 'ABRIL': case 'MAIO': case 'JUNHO': case '4': case '5': case '6':
            estação = 'PRIMAVERA'
            break
        case 'JULHO': case 'AGOSTO': case 'SETEMBRO': case '7': case '8': case '9':
            estação = 'VERÃO'
            break
        case 'OUTUBRO': case 'NOVEMBRO': case 'DEZEMBRO': case '10': case '11': case '12':
            estação = 'OUTONO'
            break
        default:
            estação = 'INDEFINIDA'
            break
    }
    resultado.innerHTML = `<p>No mês de <mark>${mês}</mark>, estamos na estação <strong><mark>${estação}</mark></strong>.</p>`
}