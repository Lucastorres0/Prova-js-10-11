function Clique() {
    window.alert('Você clicou no botão!')
}