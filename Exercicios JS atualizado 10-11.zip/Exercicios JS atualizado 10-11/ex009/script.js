var contador = 0
var result = document.querySelector('section#resultado')

function Contar() {
    contador++
    result.innerHTML = `<p>O contador está com <mark>${contador}</mark> cliques</p>`
}

function Zerar() {
    contador = 0
    result.innerHTML = null
}