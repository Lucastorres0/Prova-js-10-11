
function Clique(){
    var palpite = Number(window.prompt('Qual é o seu palpite?'))
    

}
