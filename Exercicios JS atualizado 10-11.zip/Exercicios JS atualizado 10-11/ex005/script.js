window.alert('Seja bem-vindo(a) ao meu site!')

function Clique() {
    var numero1 = Number(window.prompt('Digite um número: '))
    var result = document.querySelector('section#resultado')

    result.innerHTML = `<p>O dobro de ${numero1} é ${numero1*2} e a metade é ${numero1/2}</p>`
}